package com.vert.logistica.pedidoapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PedidoapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
