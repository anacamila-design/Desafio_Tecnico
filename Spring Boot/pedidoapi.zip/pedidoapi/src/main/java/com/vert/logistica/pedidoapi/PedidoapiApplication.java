package com.vert.logistica.pedidoapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PedidoapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(PedidoapiApplication.class, args);
	}

}
